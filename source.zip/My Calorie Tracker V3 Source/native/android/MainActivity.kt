package com.example.my_calorie_tracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "my_calorie_tracker/steps"
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "getSteps" -> {
                    val p = getSharedPreferences("steps", MODE_PRIVATE)
                    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                    result.success(if (p.getString("day", "") == today) p.getInt("count", 0) else 0)
                }
                "startTracking" -> {
                    if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 111)
                        result.error("PERMISSION", "Grant Physical Activity permission, then tap Enable again.", null)
                    } else {
                        try {
                            ContextCompat.startForegroundService(this, Intent(this, StepTrackingService::class.java))
                            result.success(true)
                        } catch (e: Exception) { result.error("START_FAILED", e.message, null) }
                    }
                }
                "stopTracking" -> { stopService(Intent(this, StepTrackingService::class.java)); result.success(true) }
                else -> result.notImplemented()
            }
        }
    }
}
