package com.example.my_calorie_tracker

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.hardware.*
import android.os.*
import java.text.SimpleDateFormat
import java.util.*

class StepTrackingService : Service(), SensorEventListener {
    private lateinit var manager: SensorManager
    private val prefs by lazy { getSharedPreferences("steps", MODE_PRIVATE) }
    private val channel = "daily_steps"
    private val notificationId = 1001
    override fun onCreate() {
        super.onCreate()
        manager = getSystemService(SENSOR_SERVICE) as SensorManager
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(channel,"Step tracking",NotificationManager.IMPORTANCE_LOW))
        val notif = buildNotification(0)
        if (Build.VERSION.SDK_INT >= 34) startForeground(notificationId, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
        else startForeground(notificationId,notif)
        val sensor = manager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if(sensor == null) {
            nm.notify(notificationId,buildNotification(0,"Step sensor unavailable on this phone"))
            stopSelf();return
        }
        manager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_NORMAL)
    }
    override fun onStartCommand(intent: Intent?, flags:Int, startId:Int):Int = START_STICKY
    private fun day():String = SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    override fun onSensorChanged(event:SensorEvent) {
        val cumulative = event.values[0].toInt()
        val today=day(); val oldDay=prefs.getString("day","")
        val previous=prefs.getInt("last",-1)
        val total=if(oldDay==today) prefs.getInt("count",0) else 0
        // A reset of the cumulative sensor value usually signals reboot.
        val delta=if(previous>=0 && cumulative>=previous) cumulative-previous else 0
        val count=(total+delta).coerceAtLeast(0)
        prefs.edit().putString("day",today).putInt("last",cumulative).putInt("count",count).apply()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(notificationId,buildNotification(count))
    }
    override fun onAccuracyChanged(sensor:Sensor?, accuracy:Int) {}
    private fun buildNotification(count:Int, override:String?=null):Notification {
        val intent=packageManager.getLaunchIntentForPackage(packageName)
        val pending=if(intent!=null) PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE) else null
        val builder=Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_directions)
            .setContentTitle("My Calorie Tracker · $count steps")
            .setContentText(override?:"Step counting is active · tap to view")
            .setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_STATUS)
        if(pending!=null) builder.setContentIntent(pending)
        return builder.build()
    }
    override fun onBind(intent:Intent?):IBinder? = null
    override fun onDestroy(){manager.unregisterListener(this);super.onDestroy()}
}
