import Flutter
import UIKit
import CoreMotion

@main
@objc class AppDelegate: FlutterAppDelegate {
  private let pedometer = CMPedometer()
  override func application(_ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    let controller = window?.rootViewController as! FlutterViewController
    let channel = FlutterMethodChannel(name: "my_calorie_tracker/steps", binaryMessenger: controller.binaryMessenger)
    channel.setMethodCallHandler { [weak self] call, result in
      guard let self = self else { result(FlutterError(code: "STATE", message: "Unavailable", details: nil)); return }
      switch call.method {
      case "getSteps":
        guard CMPedometer.isStepCountingAvailable() else { result(FlutterError(code:"NO_SENSOR",message:"Pedometer unavailable",details:nil)); return }
        let start = Calendar.current.startOfDay(for: Date())
        self.pedometer.queryPedometerData(from: start, to: Date()) { data, error in
          DispatchQueue.main.async {
            if let error = error { result(FlutterError(code:"MOTION",message:error.localizedDescription,details:nil)) }
            else { result(data?.numberOfSteps.intValue ?? 0) }
          }
        }
      case "startTracking":
        // Core Motion tracks device steps at the OS level; iOS does not permit a permanent notification.
        result(true)
      case "stopTracking": result(true)
      default: result(FlutterMethodNotImplemented)
      }
    }
    GeneratedPluginRegistrant.register(with: self)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
