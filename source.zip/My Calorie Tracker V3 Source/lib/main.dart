import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const CalorieApp()); }

class CalorieApp extends StatelessWidget {
  const CalorieApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'My Calorie Tracker', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff16a178)), useMaterial3: true),
    home: const TrackerPage(),
  );
}

class TrackerPage extends StatefulWidget { const TrackerPage({super.key}); @override State<TrackerPage> createState() => _TrackerPageState(); }
class _TrackerPageState extends State<TrackerPage> with WidgetsBindingObserver {
  static const platform = MethodChannel('my_calorie_tracker/steps');
  final weight = TextEditingController(text:'93');
  final age = TextEditingController(text:'50');
  final heartRate = TextEditingController(text:'110');
  final manualSteps = TextEditingController(text:'0');
  String exercise = 'Light jogging on spot';
  int steps = 0, seconds = 0, dailyGoal = 8000;
  bool tracking = false, stopwatch = false;
  String sensorStatus = 'Not connected';
  Timer? poller, watch;
  List<String> history = [];
  @override void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); _load(); poller=Timer.periodic(const Duration(seconds: 5), (_) => _updateSteps()); }
  @override void didChangeAppLifecycleState(AppLifecycleState state) { if(state==AppLifecycleState.resumed) _updateSteps(); }
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); if(!mounted)return; setState(() { weight.text=(p.getDouble('weight')??93).toStringAsFixed(0); age.text='${p.getInt('age')??50}'; dailyGoal=p.getInt('goal')??8000; history=p.getStringList('history')??[]; }); await _updateSteps(); }
  Future<void> _updateSteps() async { try { final count=await platform.invokeMethod<int>('getSteps'); if(!mounted)return; setState(() {steps=count??0; sensorStatus='Connected';}); } on PlatformException catch(e) { if(mounted)setState(()=>sensorStatus=e.message??'Sensor unavailable'); } on MissingPluginException {if(mounted)setState(()=>sensorStatus='Requires native app build');} }
  Future<void> _startTracking() async { try { await platform.invokeMethod('startTracking'); if(!mounted)return; setState(()=>tracking=true); await _updateSteps(); } on PlatformException catch(e) {if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message??'Tracking unavailable')));}}
  Future<void> _stopTracking() async { try { await platform.invokeMethod('stopTracking'); if(mounted)setState(()=>tracking=false); } catch (_) {} }
  void _toggleWatch() { if(stopwatch){watch?.cancel();} else {watch=Timer.periodic(const Duration(seconds:1),(_){if(mounted)setState(()=>seconds++);});} setState(()=>stopwatch=!stopwatch); }
  int get currentMax => (220-(int.tryParse(age.text)??50)).clamp(100,220);
  double get kg => double.tryParse(weight.text)??93;
  double get met => {'Office walking':2.5,'Light jogging on spot':4.0,'Faster jogging':5.0,'Vigorous stationary run':8.0}[exercise]??4;
  double get exerciseKcal => kg * met * seconds / 3600;
  double get stepKcal => (steps+(int.tryParse(manualSteps.text)??0))*kg*.0005;
  Future<void> _saveSession() async {final p=await SharedPreferences.getInstance();final now=DateTime.now();final entry='${now.year}-${now.month.toString().padLeft(2,'0')}-${now.day.toString().padLeft(2,'0')} · $exercise · ${(seconds/60).toStringAsFixed(1)} min · ${exerciseKcal.round()} kcal';setState(()=>history.insert(0,entry));await p.setStringList('history',history);}
  Future<void> _saveProfile() async {final p=await SharedPreferences.getInstance();await p.setDouble('weight',kg);await p.setInt('age',int.tryParse(age.text)??50);if(mounted)setState((){});}
  Widget metric(String label,String value,IconData icon) => Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(15), child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:const Color(0xff159b73)),const SizedBox(height:9),Text(label,style:const TextStyle(fontSize:12)),Text(value,style:const TextStyle(fontSize:23,fontWeight:FontWeight.bold))]))));
  @override Widget build(BuildContext context) {
    final rate=int.tryParse(heartRate.text)??0;
    return Scaffold(appBar:AppBar(title:const Text('My Calorie Tracker V3')),body:ListView(padding:const EdgeInsets.all(12),children:[
      Text('Phone pedometer · $sensorStatus',style:TextStyle(color:Theme.of(context).colorScheme.primary)),
      Row(children:[metric('Today steps','${steps+(int.tryParse(manualSteps.text)??0)}',Icons.directions_walk),metric('Step calories','${stepKcal.round()} kcal',Icons.local_fire_department)]),
      LinearProgressIndicator(value:((steps+(int.tryParse(manualSteps.text)??0))/dailyGoal).clamp(0,1)),
      Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Text('Daily step goal: $dailyGoal · Phone steps $steps; manually added ${manualSteps.text}')),
      Wrap(spacing:8,children:[FilledButton.icon(onPressed:_startTracking,icon:const Icon(Icons.play_arrow),label:const Text('Enable background steps')),OutlinedButton(onPressed:_stopTracking,child:const Text('Stop tracking')),OutlinedButton(onPressed:()=>setState(()=>dailyGoal=dailyGoal==8000?10000:8000),child:const Text('Toggle goal 8k/10k'))]),
      const Divider(), const Text('Personal profile',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
      Row(children:[Expanded(child:TextField(controller:weight,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Weight (kg)'),onChanged:(_)=>setState((){}))),const SizedBox(width:12),Expanded(child:TextField(controller:age,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Age'),onChanged:(_)=>setState((){}))),IconButton(onPressed:_saveProfile,icon:const Icon(Icons.save),tooltip:'Save profile')]),
      TextField(controller:manualSteps,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Optional manually added steps (not sensor steps)'),onChanged:(_)=>setState((){})),
      const Divider(),const Text('Exercise stopwatch',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
      DropdownButton<String>(isExpanded:true,value:exercise,items:['Office walking','Light jogging on spot','Faster jogging','Vigorous stationary run'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>exercise=v!)),
      Center(child:Text('${(seconds~/60).toString().padLeft(2,'0')}:${(seconds%60).toString().padLeft(2,'0')}',style:const TextStyle(fontSize:50,fontWeight:FontWeight.bold))),
      Center(child:Text('Estimated session calories: ${exerciseKcal.round()} kcal (total energy)')),
      Wrap(spacing:8,children:[FilledButton(onPressed:_toggleWatch,child:Text(stopwatch?'Pause':'Start')),OutlinedButton(onPressed:(){watch?.cancel();setState((){stopwatch=false;seconds=0;});},child:const Text('Reset')),OutlinedButton(onPressed:seconds==0?null:_saveSession,child:const Text('Save session'))]),
      const Divider(),const Text('Heart-rate zones',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
      TextField(controller:heartRate,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Heart rate (BPM) — manual entry'),onChanged:(_)=>setState((){})),
      Text('Estimated maximum heart rate: $currentMax BPM'),
      ...List.generate(3,(i){final min=((i+5)/10*currentMax).round(), max=((i+6)/10*currentMax).round();return ListTile(leading:Icon(Icons.favorite,color:rate>=min&&rate<max?Colors.red:Colors.grey),title:Text('Zone ${i+1} · $min–$max BPM'),subtitle:Text(rate>=min&&rate<max?'Current zone':'${(i+5)*10}–${(i+6)*10}% of estimated maximum'));}),
      const Text('Heart rate is not automatically measured. No watch integration in this build.',style:TextStyle(fontSize:12)),
      const Divider(),const Text('Saved exercise sessions',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
      if(history.isEmpty)const Text('No saved sessions yet.'),...history.take(30).map((e)=>ListTile(dense:true,title:Text(e))),
      const SizedBox(height:25),
    ]));
  }
  @override void dispose(){WidgetsBinding.instance.removeObserver(this);poller?.cancel();watch?.cancel();weight.dispose();age.dispose();heartRate.dispose();manualSteps.dispose();super.dispose();}
}
