# My Calorie Tracker V3 — cross-platform source starter

**Status:** source code prototype; NOT a compiled or device-tested APK/IPA. A Flutter toolchain plus Android Studio or Xcode are needed.

## Features already coded
- Flutter UI: 93 kg default, editable weight and age, step goal, phone steps, optional manually added steps, active calorie estimate, exercise stopwatch, save exercise sessions, estimated HR zones 1–3 with manual BPM.
- Android: Kotlin `TYPE_STEP_COUNTER` sensor foreground service, ongoing notification, steps stored in Android SharedPreferences, physical-activity permission request on Android 10+.
- iPhone: Swift Core Motion `CMPedometer` step totals for today, while app is in foreground; OS can retain pedometer history between openings.

## How to assemble
1. Install Flutter SDK, Android Studio and (for iOS) Xcode on a Mac. Run `flutter doctor`.
2. In a terminal, `flutter create --platforms=android,ios --org com.example my_calorie_tracker`.
3. Replace generated `pubspec.yaml` and `lib/main.dart` with the corresponding files from this archive.
4. Put `native/android/MainActivity.kt` and `native/android/StepTrackingService.kt` into `android/app/src/main/kotlin/com/example/my_calorie_tracker/` replacing generated MainActivity. If the package name differs, fix Kotlin `package` and directory.
5. Merge the entries in `native/android/AndroidManifest-additions.xml` into `android/app/src/main/AndroidManifest.xml` in the indicated locations. Ensure Android `compileSdk` is at least 34 and `minSdk` at least 26.
6. For iOS replace `ios/Runner/AppDelegate.swift` with `native/ios/AppDelegate.swift`, add `NSMotionUsageDescription` to `ios/Runner/Info.plist` with explanation `Count your steps to display daily walking activity`. Use a physical iPhone to test.
7. Run `flutter pub get`, then `flutter run` on a real Android phone or iPhone.
8. For release after testing: Android `flutter build apk --release`; iOS requires macOS/Xcode, signing and distribution using Apple developer tooling.

## Important limitations / next engineering tasks
- **Android:** foreground service must be activated by user in the foreground; user or OS can terminate it. Notification permission should also be requested on Android 13+ for normal notification visibility. Android 14+ health foreground-service permission and policy must be verified. The service uses the step counter's cumulative-since-reboot readings; steps around midnight and phone reboots can be imperfect. A production app needs more robust day-boundary/reboot reconciliation, boot handling, service restart handling, better permissions UX and device QA. The notification may not be permanently pinned: users/OS can dismiss or stop it.
- **iPhone:** uses Core Motion, not Apple Health. When the app reopens, it retrieves the phone's recorded steps. There is NO ongoing/pinned notification or Live Activity in this prototype; adding an iOS widget or time-limited Live Activity is a separate development task, not an equivalent to Android's always-on notification.
- **Heart rate:** manually entered, NOT automatically read from a watch. No Health Connect / Apple Health watch sync implemented.
- Saved exercise sessions are local on the phone via shared_preferences. Manual steps and goal are not persisted in this prototype. Background periodic Flutter polling is not guaranteed while backgrounded; Android tracking occurs within native service.
- This is not medical-grade monitoring. MET/step calorie estimates are approximate; exercise stopwatch calories are **total** exercise calories while walking-step calories are estimated **active** calories. Avoid adding both for overlapping activity.
- Flutter/Gradle/Swift project cannot be compiled or tested inside the current environment because Flutter/Android SDK/Xcode are not installed. Review and QA before Play Store / App Store submission.

## Accuracy and privacy
Step data is local; no analytics/server or user account. No location permissions requested. Do not use these figures for medical treatment.
